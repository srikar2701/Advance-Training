package com.SplitMethod;

public class SplitExpression {
	public static void main(String[] args) {
		
	
	String txt= (" 23  +  45  -  (  343  /  12  ) ");
	String[] w=txt.split(" ");
	
	for(int i=0;i<w.length;i++){  
		System.out.println(" "+w[i]); 
		
	}
}

}