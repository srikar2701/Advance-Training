package com.training;

public abstract class Instruements {
	public abstract void Play();
}