package com.StringHandling;

public class JavaIsSimple {

	public static void main(String[] args) {

		String txt = "JAVA is Simple";
		System.out.println(txt.toUpperCase());
		System.out.println(txt.toLowerCase());

		String[] words = txt.split(" "); // 1st words of letter
		for (int i = 0; i < words.length; i++) {
			String s = words[i];
			System.out.print(s.charAt(0)+" ");

		}
		System.out.println(" ");
		
		String ans = "";
        for (int i = words.length - 1; i >= 0; i--)
        {
            ans += words[i]+" ";
        }
        System.out.println(ans.substring(0,
                                  ans.length() - 1));
        StringBuilder sb = new StringBuilder(ans);
        System.out.println(sb.reverse());
    
		// Total Length
		System.out.println("length of string " + txt.length());
	}
}

