CREATE DATABASE bookstores ;
use bookstore ;
CREATE TABLE `book` (
  `Book_id` varchar(10) NOT NULL,
  `Book_name` varchar(50) NOT NULL,
  `Author` varchar(60) NOT NULL,
  `Price` varchar(10) NOT NULL, 
  constraint pk1 primary key (Book_id) 
);

CREATE TABLE `order_detail` (
  `Order_Id` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `mobileno` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `Order_Date` date NOT NULL,
  `Quantity` varchar(11) NOT NULL,
   constraint pk1 primary key (Order_Id) 
   );

CREATE TABLE `User` (
  `first_name` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `registration_date` date NOT NULL
);
 
 insert into book  values ( ' 1 ', 'Let Us C' , 'C Programming' , 400.00 ) ;
 insert into book  values ( ' 2 ', 'Thinking in Java' , 'Thinking in Java'  , 300.00 ) ;
 insert into book  values ( ' 3 ', 'Computer Networking' , 'James F. Kurose' , 250.00 ) ;
 insert into book  values ( ' 4 ', 'Head First C#' , 'Andrew Stellman ' , 400.00 ) ;
 insert into book  values ( ' 5', 'What is HTML5 ?' , 'Brett Mclaughlin ' , 300.00 ) ;
 insert into book  values ( ' 6 ', 'HTML in Action' , 'Joe Lennon ' , 569.00 ) ;
 insert into book  values ( ' 7 ', 'OOP with C++' , 'Balagurusamy ' , 308.00 ) ;
 insert into book  values ( ' 8 ', 'C++ : The Complete Reference' , 'Herbert Schildt ' , 532.00 ) ;
 insert into book  values ( ' 9 ', 'Head First SQl' , 'Lynn Beighley ' , 450.00 ) ;
 insert into book  values ( ' 10 ', 'SQL : The Complete References' , ' James Groff ' , 667.00 ) ;
 
 
 insert into  User values ('Srikar' , 'Mambalam' , 'sriakr@gmail.com' ,'9673960407 ', 'srikar27 ' , '2017-12-05 ' ) ;
 insert into  User values ('Adithya' , 'T-nagar ' , 'adithya@rediffmail.com' ,'7845127421' , 'Adi2701' , '2018-9-12 ' ) ;
 insert into  User values (' Ravi ' , 'Mudhichur ' , 'ravi@gmail.com' ,'9878454503' , 'ravi@ ' , '2019-10-08 ' ) ;
 insert into  User values ('Nikhil ' , 'guindy' , 'Nikhil@pmo.nic.in' , '8877990011 ', '	Nikhil3 ' , '2016-11-08 ' ) ;
 insert into  User values ('Kavita ' , 'Rakshak Nagar Gold ' , 'kavi23@gmail.com' , '98978521402' , 'Alia8& ' , '2016-11-08 ' ) ;


 insert into order_detail  values ( '1' ,  ' Mambalamr ' , '9673960407' , 'Srikar ' ,'2017-12-05 ' , '3' );
 insert into order_detail  values ( '2' ,  ' T-Nagar ' , '875451395 ' , ' Adithya ' , '2018-9-12 ' , '3' );
 insert into order_detail  values ( '3' ,  ' Mudhichur' , '7845127845' , ' Ravi' , '2019-10-08 ' , '2' );
 insert into order_detail  values ( '4' ,  ' Guindy ' , '784512788' ,  'Nikhil' , '2016-11-08 ' , '3' );
 insert into order_detail  values ( '5' ,  ' Wadganosheri ' , '784578215' , ' Amol ' , '2016-11-08 ' , '3' );
 insert into order_detail  values ( '6' ,  ' Bangalore ' , '78521868' , 'Amit ' , '2016-11-08 ' , '2' ); 
 